/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>

#include "helpers.h"

/**
 * Returns true if value is in array of n values, else false.
 */
bool search(int value, int values[], int n)
{
    // TODO: implement a searching algorithm
    //binary search
    int start = 0;
    int end = n-1;
    
    while(start <= end)
    {
        int middle = (start + end) / 2;
        
        if (values[middle] == value)
        {
            return true;
        }
        else if (values[middle] > value)
            {
                end =  middle - 1;
            }
        else if (values[middle] < value)
            {
                start = middle + 1;
            }
    }
   
    return false;    
    //linear search
    /*if (n < 0)
    {
        return false;
    }
 
    int flag = -1;
    for (int i = 0; i < n; i++)
    {
        if (values[i] == value)
        {
            flag = i + 1;
        }
    }
    if (flag == -1) 
    {
        return false;
    }
    else
    {
        return true;
    }*/

}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    // TODO: implement an O(n^2) sorting algorithm
    
    int shift;
    do
    {
        shift = 0;
        for (int i = 0; i < n - 1; i++)
        {
            if (values[i] > values[i + 1])
            {
                int h = 0;
                h = values[i];
                values[i] = values[i + 1];
                values[i + 1] = h;
                shift++;
            }
        }
        
    }
    while(shift > 0);
    return;
}

